from fontstyle.core import *

__version__ = '1.0.5'
__author__ = 'gellel'
__email__ = 'lindsay.gelle@gmail.com'
__source__ = 'https://github.com/gellel/fontstyle/'
__license__ = 'MIT'