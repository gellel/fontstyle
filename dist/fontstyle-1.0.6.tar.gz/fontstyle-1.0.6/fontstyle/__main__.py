#!/usr/bin/python
# -*- coding: utf-8 -*-
#sys.argv[1:]

#########################
### File requirements ###
#########################
### import main module function
from core import main
### import system module
import sys

####################
### File manager ###
####################

if __name__ == '__main__':

	main(*sys.argv[1:])
						